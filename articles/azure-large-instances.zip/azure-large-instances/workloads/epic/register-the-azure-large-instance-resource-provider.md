---
title: Architecture
description: Explains how to register the ALI source provider.
ms.topic: conceptual
author: jjaygbay
ms.author: jacobjaygbay
ms.subservice: baremetal-epic
ms.date: 06/01/2023
---

# Register the ALI source provider h1

content




## Next steps

Learn how to identify and interact with ALI instances through the Azure portal.

> [!div class="nextstepaction"]
> [What is Azure for Large Instances?](../../what-is-azure-for-large-instances.md)


