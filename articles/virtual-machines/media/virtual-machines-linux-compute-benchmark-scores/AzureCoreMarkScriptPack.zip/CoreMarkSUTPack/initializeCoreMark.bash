#!/bin/bash
#
# initializeCoreMark.bash
#
# Wrapper called by test framework to start test run.
#
#*********************************************************
#
#    Copyright (c) Microsoft Corporation. All rights reserved.
#    This code is licensed under the Microsoft Public License.
#    THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF
#    ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY
#    IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR
#    PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.
#
#*********************************************************
#2345678901234567890123456789012345678901234567890123456789012345678901234567890

. provLib.bash
AbendOnError $? "Dot execute provLib.bash environnment file."

rm -rf $TOUT
AbendOnError $? "Delete the old Documents."

at -f processCoreMarkSuite.sh now
AbendOnError $? "Run the test suite script using at."

#
# End of initializeCoreMark.bash
