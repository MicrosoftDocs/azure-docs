#!/bin/bash
#
# writeResources.bash
#
# Collects all the report data (logs, cpu, memory stats, etc - not used in the CSVs)
#
#*********************************************************
#
#    Copyright (c) Microsoft Corporation. All rights reserved.
#    This code is licensed under the Microsoft Public License.
#    THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF
#    ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY
#    IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR
#    PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.
#
#*********************************************************
#2345678901234567890123456789012345678901234567890123456789012345678901234567890

. provLib.bash
AbendOnError $? "Dot execute provLib.bash environnment file."

function printUsage
{
        echo "USAGE:  ./writeResources.bash [-h|--help|-?]"
}

#### Initializations

readonly LSPEC=$TOUT/ACU_TestResources
readonly OSPEC=$LSPEC.$(date +%Y%m%d%H%M%S)

if (( $# > 0 ))
then
        r=0
        if [[ '-h' != "$1" &&  '-?' != "$1" &&  '--help' != "$1" ]]
        then
                echo "ERROR:  Except for Help, normal script execution has no argument."
                r=1
        fi
        printUsage
        exit $r
fi

#### Main activities

cat >$OSPEC <<EOD

lscpu output ($HOSTNAME/$(date)):
$(lscpu)

Linux free -h:
$(free -h)(

vmstat:
$(vmstat)

Then just dump a bunch of stuff from /proc on the off chance it may be helpful
some day:
cat /proc/cpuinfo
$(cat /proc/cpuinfo)
cat /proc/iomem
$(cat /proc/iomem)
cat /proc/loadavg
$(cat /proc/loadavg)
cat /proc/meminfo
$(cat /proc/meminfo)
cat /proc/schedstat
$(cat /proc/schedstat)
cat /proc/stat
$(cat /proc/stat)
cat /proc/swaps
$(cat /proc/swaps)
cat /proc/uptime
$(cat /proc/uptime)
cat /proc/version
$(cat /proc/version)
cat /proc/consoles
$(cat /proc/consoles)
cat /proc/locks
$(cat /proc/locks)
cat /proc/misc
$(cat /proc/misc)
cat /proc/fb
$(cat /proc/fb)
EOD

rm -f $LSPEC
ln -s $OSPEC $LSPEC

# End of writeResources.bash
