#!/bin/bash
#
# chkCoreMark.bash
#
# Check to make sure CoreMark isn't already running.  This is typically a NOOP and can usually be ignored.
#
#*********************************************************
#
#    Copyright (c) Microsoft Corporation. All rights reserved.
#    This code is licensed under the Microsoft Public License.
#    THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF
#    ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY
#    IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR
#    PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.
#
#*********************************************************
#2345678901234567890123456789012345678901234567890123456789012345678901234567890

. provLib.bash
AbendOnError $? "Dot execute provLib.bash environnment file."

echo "Check for processes with the string 'CoreMark', case insensitive."
if chkProcessesWithString CoreMark "$1"
then
	ps auxw
	exit 1
fi
echo "Check for processes with the string 'make', case insensitive."
if chkProcessesWithString make
then
	ps auxw
	exit 1
fi
echo "Check for processes with the string 'defunct', case insensitive."
if chkProcessesWithString defunct
then
	ps auxw
	exit 1
fi
exit 0

#
#2345678901234567890123456789012345678901234567890123456789012345678901234567890
# End of chkCoreMark.bash
