#!/bin/bash
#
# buildCoreMark.bash
#
# Builds the configured version of CoreMark (we configure it for the # of threads to run, and may have multiple sets of cores)
# For standard Azure benchmarking, set the # of threads to the # of virtual CPUs.
# Currently only support PThreads (not forks or packages)
#
#*********************************************************
#
#    Copyright (c) Microsoft Corporation. All rights reserved.
#    This code is licensed under the Microsoft Public License.
#    THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF
#    ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY
#    IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR
#    PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.
#
#*********************************************************
#2345678901234567890123456789012345678901234567890123456789012345678901234567890

. provLib.bash
AbendOnError $? "Dot execute provLib.bash environnment file."

COREMARKDIR=coremark_v1.0
COREMARKTGZ=$TDOWN/coremark_v1.0.tgz

AbendOnNoSuchFile $COREMARKTGZ

AssureGone $COREMARKDIR
AssureGone $TBIN

mkdir -p $TBIN
AbendOnError $? "Recreation of $TBIN."
AbendOnNoSuchDir $TBIN

tar zxvf $COREMARKTGZ
AbendOnError $? "Tar extract \$COREMARKTGZ:  'tar zxvf $COREMARKTGZ'."

HERE=$PWD
cd $COREMARKDIR
AbendOnError $? "Enter coremark directory."

### This line must exist, more or less, in the linux64/core_portme.mak file:
###	LFLAGS_END += -lrt -lpthread
#if [[ -z $(grep 'LFLAGS_END.*lpthread') ]]
#then
sed 's:^LFLAGS_END +=.*$:LFLAGS_END += -lrt -lpthread:' linux64/core_portme.mak >/tmp/modifiedmf
mv /tmp/modifiedmf linux64/core_portme.mak
#fi

### Concurrency Count Loop
#  NOTE:  Decision on Meeting of September 15, 2015 to only run tests on PTHREAD
#	and for  # cpus, not for 1 or double # cpus, with exception of case when 
#	there are multiple theads per core.  Thus now getThreadSets drives
#	the outer loop here:
for cci in $(getThreadSets)
do

    ### Concurrency Type Loop
    #for cti in FORK PTHREAD
    for cti in PTHREAD
    do
	make clean PORT_DIR=simple

	if (( cci < 10 ))
	then
	    zfcci=0$cci
	else
	    zfcci=$cci
	fi

	cmvn=CoreMark_Make.$zfcci.$cti
	CBE=$TOUT/$cmvn.Build.stderr
	CBO=$TOUT/$cmvn.Build.stdout
#2345678901234567890123456789012345678901234567890123456789012345678901234567890
	XCFLAGS="-DMULTITHREAD=$cci -DUSE_$cti=1"
	mkcmd="make XCFLAGS=\"$XCFLAGS\" PORT_DIR=linux64 >$CBO 2>$CBE"
	eval $mkcmd
	if (( $? != 0 ))
	then
		echo "ERROR returned for coremark make."
		echo "make command:  $mkcmd"
		continue

	elif [[ -n $(grep ERROR $CBE) || -n $(grep ERROR $CBO) ]]
	then
		echo "Build error detected in make logs."
		echo "make command:  $mkcmd"
		continue
	fi

	for l in 1 2
	do
		cp run$l.log $TOUT/run$l.log.$zfcci.$cti
	done

	CMEXE=$TBIN/coremark.$zfcci.$cti.exe

	cp coremark.exe $CMEXE
	AbendOnError $? "Copy to $CMEXE to designate its use."

	chmod 0744 $CMEXE
	AbendOnError $? "Make $CMEXE executable by owner only, readable by all."

    done

done

cd $HERE

#
# End of buildCoreMark.bash
