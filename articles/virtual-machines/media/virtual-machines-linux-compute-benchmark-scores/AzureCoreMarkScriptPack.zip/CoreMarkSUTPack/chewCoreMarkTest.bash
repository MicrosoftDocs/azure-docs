#!/bin/bash
#
# chewCoreMarkTest.bash
#
# Executes Python parser to collect data from all the output files into a CSV file for easy import to Excel
#
#*********************************************************
#
#    Copyright (c) Microsoft Corporation. All rights reserved.
#    This code is licensed under the Microsoft Public License.
#    THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF
#    ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY
#    IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR
#    PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.
#
#*********************************************************
#2345678901234567890123456789012345678901234567890123456789012345678901234567890

. provLib.bash
AbendOnError $? "Dot execute provLib.bash environnment file."

b=/tmp/cmreportsegment.lst
o=/tmp/cm.csv
rm -f $b
rm -f $o 
while read line
do

	if [[ $line =~ ^Begin ]]
	then
		rm -f $b
	elif [[ $line =~ ^End ]]
	then
		./parseCoreMark.py $b $TOUT/ACU_TestResources >>$o
	else
		echo $line >>$b
	fi

done <$TOUT/CoreMarkTest.stdout

sort $o | uniq >$TOUT/ParsedTestData.csv
#
#2345678901234567890123456789012345678901234567890123456789012345678901234567890
# End of chkCoreMarkTest.bash
