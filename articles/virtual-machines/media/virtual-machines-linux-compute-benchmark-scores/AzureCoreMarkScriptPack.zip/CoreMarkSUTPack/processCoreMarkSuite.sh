#!/bin/sh
# Do Not Call Bash in this script. It should be Bourne Shell Compliant.
#
#  processCoreMarkSuite.sh
# 
# Main script started by batch handler.  Handles all other processing to configure, build, and run CoreMark.  Collects results.
#
#*********************************************************
#
#    Copyright (c) Microsoft Corporation. All rights reserved.
#    This code is licensed under the Microsoft Public License.
#    THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF
#    ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY
#    IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR
#    PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.
#
#*********************************************************
#2345678901234567890123456789012345678901234567890123456789012345678901234567890

# Sourcing requires explicit path in sh:
. ./provEnv

CISpec=$THOME/ConfiguredIterationsOnVM
if [ -e $CISpec ]
then
	CIOV=$(cat $CISpec)
else
	CIOV=7
fi

CMD=$TOUT/CoreMarkDone
CMF=$TOUT/CoreMarkFATALERROR

CBE=$TOUT/CoreMarkBuild.stderr
CBO=$TOUT/CoreMarkBuild.stdout
CTE=$TOUT/CoreMarkTest.stderr
CTO=$TOUT/CoreMarkTest.stdout

MTE=$TOUT/MBWTest.stderr
MTO=$TOUT/MBWTest.stdout

TAE=$TOUT/Admin.stderr
TAO=$TOUT/Admin.stdout

echo "First Check at start of run:" >$TOUT/processesCheck.stdout
./chkCoreMark.bash >>$TOUT/processesCheck.stdout
if [ $? -ne 0 ]
then
echo "trace 2b"
	date >>$CMF
	echo "FATAL:  Processes in memory may taint tests.  Exiting." >>$CMF
	exit 9 
fi

# Initial Resource Check.  Note output file from within this script ends with
# date/time, so each call makes a new file.
./writeResources.bash >$TAO 2>$TAE

./buildCoreMark.bash $ltc $ttype >$CBO 2>$CBE
if [ $? -ne 0 ]
then
	date >>$CMF
	echo "ERROR building CoreMark test executable for ACU tests." >>$CMF
	exit 9
fi

cpus=$(lscpu | grep '^CPU(s):' | awk '{print $2}')
mhz=$(lscpu | grep 'CPU MHz:' | awk '{print $3}' | sed 's/\..*$//')
bogomips=$(lscpu | grep 'BogoMIPS:' | awk '{print $2}' | sed 's/\..*$//')
stepping=$(lscpu | grep 'Stepping:' | awk '{print $2}')
gbmem=$(free -g | grep '^Mem: *' | awk '{print $2}')
#guessits=$(expr $cpus \* $mhz \* $gbmem)
# NOTE2:  The above is also faulty for timing.  Changing tentatively to
# 100* Bogomips.
# NOTE1 The above is fine for tests, I suspect for production, with the following
# multiplier of 16, we'd get something close to what we want of between 1 and
# two hours for the average machines; at least it seems like a good wild guess.
#guessits=$(expr $cpus \* $mhz \* $gbmem \* 16)
guessits=$(expr $bogomips \* 100)


echo "NO Second Check At This Time just before tests:" >>$TOUT/processesCheck.stdout
#./chkCoreMark.bash >>$TOUT/processesCheck.stdout
#if [ $? -ne 0 ]
#then
	#date >>$CMF
	#echo "FATAL:  Processes in memory may taint tests.  Exiting." >>$CMF
	#exit 9 
#fi

# Post Build Resource Check.
./writeResources.bash >>$TAO 2>>$TAE

i=0
while [ $i -lt $CIOV ]
do
	for exe in $TBIN/*
	do
		echo "Begin Run for $exe at $(date):" >>$CTE
		echo >>$CTO
		echo "Begin Run for $exe at $(date):" >>$CTO
		echo >>$CTO
		# Note the following report item is a hack.  Beyond prototype state, we want an eval
		# execution procedure like the one I had for fio runs. -xc
		# Begin special code dependency.
		echo  >>$CTO
		echo "Cmd used for tests by hand:  $exe 0x3415 0x3415 0x66 $guessits 7 1 2000" >>$CTO
		echo  >>$CTO
		$exe 0x3415 0x3415 0x66 $guessits 7 1 2000 >>$CTO 2>>$CTE
		# End special code dependency.
		er=$?
		if [ $er -ne 0 ]
		then
			echo "ERROR '$er' running CoreMark test executable for ACU tests." >>$CTE
		fi
		echo "End of Run for $exe at $(date)." >>$CTE
		echo >>$CTO
		echo "End of Run for $exe at $(date)." >>$CTO
		echo >>$CTO
	done

	i=`expr $i + 1`
done

# Post CoreMark Resource Check.
./writeResources.bash >>$TAO 2>>$TAE

./chewCoreMarkTest.bash >>$TAO 2>>$TAE

# Finish with Documents Directory Copy:
./zipUpTOUT.bash CoreMark >>$TAO 2>>$TAE

# End Suite List

# Write Done File:
date > $CMD
#
# End of processCoreMarkSuite.sh
