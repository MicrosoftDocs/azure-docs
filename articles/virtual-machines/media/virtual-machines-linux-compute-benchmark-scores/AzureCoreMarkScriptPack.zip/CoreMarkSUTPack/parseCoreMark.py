#!/usr/bin/python

# parseCoreMark.py

# parses coremark output data and formats into CSV output (one header and one data record) which is written to stdout.

#*********************************************************
#
#    Copyright (c) Microsoft Corporation. All rights reserved.
#    This code is licensed under the Microsoft Public License.
#    THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF
#    ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY
#    IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR
#    PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.
#
#*********************************************************

import sys
import os
import re



def printUsage():
    print "USAGE:  ./parseCoreMark.py <coremarkReport> <resourceReport>"

if __name__ == '__main__':


    # Initializations

    if len(sys.argv) == 3:
        _cmrspec = sys.argv[1]
        _rrspec = sys.argv[2]
        #print _fspec
    else:
        print 'Invalid Usage.'
        print "Argument count:  %d" % len(argv)
        printUsage()
        exit(1)

    # Really Mainy Stuff

    print "Concurrency_type,Threads,CoreMark_Size,Total_ticks,Total_time_secs,Iterations_per_Sec,Iterations,Correct_operation,",
    print "CPU_COUNT,THREADS_PER_CORE,NUMA_NODE_COUNT,MODEL_NAME,HYPERVISOR_VENDOR,L2_CACHE,L3_CACHE,MEMORY_SIZE"


    with open(_cmrspec, 'r') as content_file:
        content = content_file.read()

    CoreMark_Size        = re.search(r'CoreMark Size.*: (\d+)',content).group(1)
    Total_ticks          = re.search(r'Total ticks.*: (\d+)',content).group(1)
    Total_time_secs_o    = re.search(r'Total time \(secs\): (\d+)\.(\d+)',content)
    Total_time_secs      = "%s.%s" % (Total_time_secs_o.group(1),Total_time_secs_o.group(2))
    Iterations_per_Sec_o = re.search(r'Iterations/Sec.*: (\d+)\.(\d+)',content)
    Iterations_per_Sec   = "%s.%s" % (Iterations_per_Sec_o.group(1),Iterations_per_Sec_o.group(2))
    Iterations           = re.search(r'Iterations *: (\d+)',content).group(1)
    Concurrency_o        = re.search(r'Parallel *(\S+) *: (\d+)',content)
    if Concurrency_o:
        Concurrency_type = Concurrency_o.group(1)
        Threads          = Concurrency_o.group(2)
    else:
        Concurrency_type = "None"
        Threads          = "1"
    Correct_operation    = re.search(r'Correct operation (\S+)',content).group(1)

    with open(_rrspec, 'r') as content_file:
        content = content_file.read()

    #CPU(s):                1
        CPU_COUNT            = re.search(r'CPU\(s\):\s+(\d+)',content).group(1)
    #Thread(s) per core:    1
        THREADS_PER_CORE     = re.search(r'Thread\(s\) per core:\s+(\d+)',content).group(1)
    #NUMA node(s):          1
        NUMA_NODE_COUNT      = re.search(r'NUMA node\(s\):\s+(\d+)',content).group(1)
    #Model name:            Intel(R) Xeon(R) CPU E5-2673 v3 @ 2.40GHz
        MODEL_NAME           = re.search(r'[M|m]odel name\s?:\s+(.+)',content).group(1)
    #Hypervisor vendor:     Microsoft
        HYPERVISOR_VENDOR    = re.search(r'Hypervisor vendor:\s+(.+)',content).group(1)
    #L2 cache:              256K
        L2_CACHE             = re.search(r'L2 cache:\s+(\S+)',content).group(1)
    #L3 cache:              30720K
        L3_CACHE             = re.search(r'L3 cache:\s+(\S+)',content).group(1)
    #Mem:           13G       1.5G        12G       144M        91M       1.2G
        MEMORY_SIZE          = re.search(r'Mem:\s+(\S+)\s+\S+\s+\S+\s+\S+\s+\S+\s+\S+',content).group(1)

    print "%s,%s,%s,%s,%s,%s,%s,%s," % (Concurrency_type,Threads,CoreMark_Size,Total_ticks,Total_time_secs,Iterations_per_Sec,Iterations,Correct_operation),
    print "%s,%s,%s,%s,%s,%s,%s,%s" % (CPU_COUNT,THREADS_PER_CORE,NUMA_NODE_COUNT,MODEL_NAME,HYPERVISOR_VENDOR,L2_CACHE,L3_CACHE,MEMORY_SIZE)
