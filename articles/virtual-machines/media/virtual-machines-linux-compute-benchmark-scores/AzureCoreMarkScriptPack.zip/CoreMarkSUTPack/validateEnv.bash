#!/bin/bash
#
# validateEnv.bash
#
# Checks to make sure environment is setup properly (optional)
#
#*********************************************************
#
#    Copyright (c) Microsoft Corporation. All rights reserved.
#    This code is licensed under the Microsoft Public License.
#    THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF
#    ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY
#    IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR
#    PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.
#
#*********************************************************
#2345678901234567890123456789012345678901234567890123456789012345678901234567890

. provLib.bash
AbendOnError $? "Dot execute provLib.bash environnment file."

function printUsage
{
	echo "USAGE:  ./validateEnv.bash"
}

#### Generic Facilities

if [[ -z $(which at 2>/dev/null) ]]
then
	echo "at not installed."
	exit 9
fi

if [[ -z $(ps auxw | grep atd | grep -v grep) ]]
then
	echo "at daemon not in memory."
	exit 9
fi

if [[ -z $(which java 2>/dev/null) ]]
then
	echo "java not installed."
	exit 9
fi

#### Script Facilities


# end of validateEnv.bash
