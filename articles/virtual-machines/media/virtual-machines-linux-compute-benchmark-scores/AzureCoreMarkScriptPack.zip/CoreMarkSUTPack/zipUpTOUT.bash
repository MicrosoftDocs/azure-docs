#!/bin/bash
#
# zipUpTOUT.bash
#
# Takes the output (document) directory and zips it up to make it easier to upload
#
#*********************************************************
#
#    Copyright (c) Microsoft Corporation. All rights reserved.
#    This code is licensed under the Microsoft Public License.
#    THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF
#    ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY
#    IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR
#    PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.
#
#*********************************************************
#2345678901234567890123456789012345678901234567890123456789012345678901234567890

. provLib.bash
AbendOnError $? "Dot execute provLib.bash environnment file."

if (( $# == 1 ))
then
	_testLabel=$1
else
	echo "USAGE:  ./zipUpTOUT.bash <Test Label>"
	exit 1
fi

zipUpTOUT $_testLabel

#
#2345678901234567890123456789012345678901234567890123456789012345678901234567890
# End of zipUpTOUT.bash
