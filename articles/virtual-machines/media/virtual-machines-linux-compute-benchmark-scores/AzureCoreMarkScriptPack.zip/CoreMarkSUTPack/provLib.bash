#
# provLib.bash -  Library to support OS environment provisioning.
#
# General libary of callable bash procedures (unit testable)
#
#*********************************************************
#
#    Copyright (c) Microsoft Corporation. All rights reserved.
#    This code is licensed under the Microsoft Public License.
#    THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF
#    ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY
#    IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR
#    PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.
#
#*********************************************************
#2345678901234567890123456789012345678901234567890123456789012345678901234567890

function AbendIfUndefined
{
	if (( $# != 1 )) 
	then
		echo "FATAL programmer syntax error using AbendIfUndefined."
		echo "USAGE:  One argument required.  $# given."
		exit 99
	fi

	local _idName=$1

	local idvalue=${!_idName}

	if [[ -z $idvalue ]]
	then
		echo "ERROR ABEND on '$_idName' not having a value:  '$idvalue'."
		exit 1
	fi
	return 0
}

function AbendOnError
{
	local _errInt=$1
	local _msgStr=$2
	if (( $# != 2 )) 
	then
		echo "FATAL programmer syntax error using AbendOnError."
		echo "USAGE:  Two arguments required.  $# given."
		exit 99
	fi
	if [[ "$1" =~ [^0-9] ]]
	then
		echo "FATAL programmer syntax error using AbendOnError."
		echo "USAGE:  First argument to AbendOnError should be integer."
		exit 99
	fi
	if (( _errInt != 0 ))
	then
		echo "Abend on non-zero ERROR Value: $_errInt, $_msgStr."
		exit $_errInt
	fi
}

function AbendOnNoSuchDir
{
	if (( $# != 1 )) 
	then
		echo "FATAL programmer syntax error using AbendOnNoSuchDir."
		echo "USAGE:  One argument required.  $# given."
		exit 99
	fi

	local _idValue=$1

	if [[ ! -e $_idValue ]]
	then
		echo "FATAL:  Directory $_idValue non-existent."
		exit 1
	fi

	if [[ ! -d $_idValue ]]
	then
		echo "FATAL:  $_idValue not a directory."
		exit 1
	fi

	return 0
}

function AbendOnNoSuchFile
{
	if (( $# != 1 )) 
	then
		echo "FATAL programmer syntax error using AbendOnNoSuchFile."
		echo "USAGE:  One argument required.  $# given."
		exit 99
	fi

	local _idValue=$1

	if [[ ! -e $_idValue ]]
	then
		echo "FATAL:  $_idValue non-existent."
		exit 1
	fi

	if [[ ! -f $_idValue ]]
	then
		echo "FATAL:  $_idValue not a regular file."
		exit 1
	fi

	return 0
}

function AssureGone
{
	if (( $# != 1 )) 
	then
		echo "FATAL programmer syntax error using AssureGone."
		echo "USAGE:  One argument required.  $# given."
		exit 99
	fi

	local _fSpec=$1

    if [[ -e $_fSpec ]]
    then
        rm -rf $_fSpec
        AbendOnError $? "remove: _fSpec."
    fi
    return 0

}

#2345678901234567890123456789012345678901234567890123456789012345678901234567890

function chkProcessesWithString
{
	_fStr=$1
	_xStr=$2
	if (( $# < 1  || 2 < $# ))
	then
		echo "USAGE:  chkProcessesWithString <filterString> [exclusionString]"
		echo "Programmer ERROR mis-calling function."
		exit 9
	fi

	# Note:  This works because $0 is allways the calling script, and does
	# not register the environment script (source script) name, nor the
	# function name. -xc
	if [[ -n $_xStr ]]
	then
		flist=$(ps auxw | grep -i "$_fStr" | grep -v "$0" | grep -v "$_xStr" | grep -v vi | grep -v nano | grep -v grep)
	else
		flist=$(ps auxw | grep -i "$_fStr" | grep -v "$0" | grep -v vi | grep -v nano | grep -v grep)
	fi
	if [[ -n $flist ]]
	then
		echo PROCESSING
		return 0
	fi
	echo ABSENT
	return 1
}

# OS Test and Identification procedures.

function getCentOSReleaseNo
{
	grep -i centos /etc/centos-release
}

function getCoreOSReleaseNo
{
	# TBD
	echo "Undefined"
}

function getFreeBSDReleaseNo
{
	# TBD
	echo "Undefined"
}

function getSuSEReleaseNo
{
	grep -i suse /etc/SuSE-release
}

function getUbuntuReleaseNo
{
	grep -i ubuntu /etc/issue
}

function getThreadSets
# For use in testing, this echos a string containing number of cpus, and if
# there are multiple CPUs, then number of threads per cpu times cpus, as a total
# number for testing.  This was created for test set use originally for the CoreMark
# tests, but is valid for any such test.
{
	logicalprocessors=$(lscpu | grep '^CPU(s):' | awk '{print $2}')
	corespersocket=$(lscpu | grep '^Core(s):' | awk '{print $2}')
	socketcount=$(lscpu | grep '^Core(s) per socket:' | awk '{print $4}')
	threadspercore=$(lscpu | grep '^Thread(s) per core:' | awk '{print $4}')
	(( physicalprocessors = socketcount * corespersocket ))
	(( lprecalc = physicalprocessors * threadspercore ))
	if (( lprecalc == logicalprocessors ))
	then
		if (( threadspercpu == 1 ))
		then
			echo $logicalprocessors
		elif (( threadspercpu > 1 ))
		then
			(( tthreads = cpus * threadspercpu ))
			echo "$physicalprocessors $logicalprocessors"
		else
			# Should never occur.  ERROR
			echo $logicalprocessors
			return 1
		fi
	else
		# Should never occur.  ERROR
		echo $logicalprocessors
		return 1
	fi
}

function isCentOS
{
	# Attention:  In shell scripting languages, zero is success and truth.
	if [[ -f /etc/centos-release ]]
	then
		# True!
		return 0
	fi
	# False
	return 1
}

function isCentOS66
{
	# Attention:  In shell scripting languages, zero is success and truth.
	if isCentOS
	then
		if [[ -n $(grep '6\.6' /etc/centos-release) ]]
		then
			# True!
			return 0
		fi
	fi
	# False
	return 1
}

function isCentOS71
{
	# Attention:  In shell scripting languages, zero is success and truth.
	if isCentOS
	then
		if [[ -n $(grep '7\.1' /etc/centos-release) ]]
		then
			# True!
			return 0
		fi
	fi
	# False
	return 1
}

function isCoreOS
{
	# TBD
	return 1
}

function isFreeBSD
{
	# TBD
	return 1
}

function isSuSE
{
	# Attention:  In shell scripting languages, zero is success and truth.
	if [[ -f /etc/SuSE-release ]]
	then
		# True!
		return 0
	fi
	# False
	return 1
}

function isOpenSuSE
{
	# Attention:  In shell scripting languages, zero is success and truth.
	if isSuSE
	then
		if [[ -n $(grep -i open /etc/SuSE-release) ]]
		then
			# True!
			return 0
		fi
	fi
	# False
	return 1
}

function isSLESSuSE
{
	# Attention:  In shell scripting languages, zero is success and truth.
	if isSuSE
	then
		if [[ -n $(grep -i 'SUSE Linux Enterprise Server' /etc/SuSE-release) ]]
		then
			# True!
			return 0
		fi
	fi
	# False
	return 1
}

function isUbuntu
{
	# Attention:  In shell scripting languages, zero is success and truth.
	if [[ -f /etc/issue && -n $(grep -i ubuntu /etc/issue) ]]
	then
		# True!
		return 0
	fi
	# False
	return 1
}

function isUbuntu1404
{
	# Attention:  In shell scripting languages, zero is success and truth.
	if isUbuntu
	then
		if [[ -n $(grep -i '14\.04' /etc/issue) ]]
		then
			# True!
			return 0
		fi
	fi
	# False
	return 1
}

function isUbuntu1504
{
	# Attention:  In shell scripting languages, zero is success and truth.
	if isUbuntu
	then
		if [[ -n $(grep -i '15\.04' /etc/issue) ]]
		then
			# True!
			return 0
		fi
	fi
	# False
	return 1
}

function isUbuntuLTS
{
	# Attention:  In shell scripting languages, zero is success and truth.
	if isUbuntu
	then
		if [[ -n $(grep -i lts /etc/issue) ]]
		then
			# True!
			return 0
		fi
	fi
	# False
	return 1
}

function zipUpTOUT
{
	_testLabel=$1
	if (( $# != 1 ))
	then
		echo "USAGE:  zipUpTOUT <testLabel>"
		echo "Programmer ERROR mis-calling function."
		exit 9
	fi 

	here=$PWD
	fspec=$APTHOME/ACU_${_testLabel}_$(date +%Y%m%d%H%M).zip
	sl=$APTHOME/ACU_${_testLabel}
	cd $TOUT
	zip -r $fspec .
	rm -f $sl
	ln -s $fspec $sl
	cd $here
}

## MAIN
#### This area to set up resources appropriate for all provisioning scripts.

if [[ -z $PROVENV ]]
then
	readonly PROVENV=provEnv
fi

. $PROVENV

#2345678901234567890123456789012345678901234567890123456789012345678901234567890
#
# End of provLib.bash
